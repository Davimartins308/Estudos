#funçoes servem para organizar o codigo, reutilizar e facilitar a manutençao

#def saudacao():
#    print("Bem-vindo")

#    saudacao()

    # funçoes com parametros
def soma(a,b):
    return a+b
resultado = soma(5,3)
print(resultado)