#usado para receber dados do usuario
nome = input("Dgite seu nome:")
idade = int(input("Digite sua idade:"))
print(f"Ola, {nome}. Voce tem { idade} anos.")