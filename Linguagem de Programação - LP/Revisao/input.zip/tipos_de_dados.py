

idade = 18      # numero inteiro
altura = 1.97   # numero decimal
nome = "Davi"   # Texto
maior = True    # boleano
