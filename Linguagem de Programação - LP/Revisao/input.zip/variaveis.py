# armazenar dados na memoria
nome = "Davi"
nota1 = 9
nota2 = 6.5

media = (nota1+nota2)/2
print(media)