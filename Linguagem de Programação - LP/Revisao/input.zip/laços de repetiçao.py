# usado para repetir um numero conhecido de vezes
#for i  in range(5):
#    print("ola",i)

#listas
#frutas = ["maça", "banana", "uva"]
#for fruta in frutas:
#    print(fruta)


#while             <--- repete a condiçao enquanto ela for verdadeira   
#contador = 1
#while contador <= 5:
#    print(contador)
#    contador += 1

