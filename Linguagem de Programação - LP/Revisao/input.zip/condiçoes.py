# usadas para tomar decisões
nota = 7

#if nota >= 7:
#print("aprovado")

#elif nota >= 5:
#print("recuperaçao")
#else :
#print("reprovado")


 # operadores
 # == igual
 # > maior
 # < menor
 # > maior ou igual
 # != diferente
 # menor ou igual 
 # and (e)
 # or (ou)
idade = 18
tem_carteira = True
if idade >= 18 and tem_carteira:
    print("pode dirigir")