# coleçao ordenada e mutavel
#criando a lista
frutas= ["maça","banana","mamao"]

#acessando
print(frutas[0])    # maça

#adicionando
frutas.append("uva")

#removendo
frutas.remove("banana")

#alterando
frutas[1] = "abacaxi"

