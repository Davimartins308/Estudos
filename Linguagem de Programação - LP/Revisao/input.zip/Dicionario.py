#armazena valores por chave

aluno = {
"nome" : "Davi",
"idade" : 17,
"nota": 9.0

}
print(aluno["nome"])

#alterando valores 
aluno["nota"] = 9.5

#adicionando nova chave
aluno["turma"]  = "3A"