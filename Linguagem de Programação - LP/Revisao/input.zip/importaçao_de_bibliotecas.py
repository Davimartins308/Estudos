# as bibliotecas sao feitas para facilitar a vida das pessoas, precisa-se importar elas

import math
import pandas as pd
import pyautogui
from datetime import datetime

#importando com apelido(muito comum)
#import pandas as pd

